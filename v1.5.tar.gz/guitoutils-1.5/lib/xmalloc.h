void *xmalloc (size_t size);
char *xstrdup (const char *s);
