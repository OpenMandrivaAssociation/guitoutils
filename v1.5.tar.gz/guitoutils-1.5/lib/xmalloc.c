#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <error.h>

void *
xmalloc (size_t size)
{
  void *p = malloc (size);
  if (! p)
    error (EXIT_FAILURE, errno, "Memory error");
  return p;
}

void *
xrealloc (char *p, size_t size)
{
  p = realloc (p, size);
  if (!p)
    error (EXIT_FAILURE, errno, "Memory error");
  return p;
}

char *
xstrdup (const char *s)
{
  char *str = strdup (s);
  if (! str)
    error (EXIT_FAILURE, errno, "Memory error (strdup)");
  return str;
}
