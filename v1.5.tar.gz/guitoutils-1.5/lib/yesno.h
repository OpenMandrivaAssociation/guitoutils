bool yesno (void);
