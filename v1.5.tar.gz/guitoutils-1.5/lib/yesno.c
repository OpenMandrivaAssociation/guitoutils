#include <stdio.h>
#include <stdbool.h>

#include "yesno.h"

bool
yesno (void)
{
  bool yes;
  int c;

  c = getchar ();
  yes = (c == 'y' || c == 'Y');

  /* Remove any character in stdin buffer. */
  while (c != '\n' && c != EOF)
    c = getchar ();

  return yes;
}
