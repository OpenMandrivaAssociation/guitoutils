#include <config.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <getopt.h>
#include <time.h>
#include <string.h>
#include <ctype.h>
#include <sys/time.h>

#include "xmalloc.h"
#include "system.h"

const char *program_name;

/* Default format string to show date. */
#define DEFAULT_FORMAT "%a %b %e %H:%M:%S %Z %Y"

/* Initial buffer size to hold the result of strftime. */
#define DEFAULT_SIZE 128

void
usage (int status)
{
  if (status != EXIT_SUCCESS)
    fprintf (stderr, "Try '%s --help' for more information.\n\n",
	     program_name);
  else
    {
      printf ("Usage: %s [FORMAT]\n\n", program_name);
      puts ("\
  -h, --help      show this help and exit\n\
  -v, --version   display version information and exit\n\n\
  For format see the strftime(3) man page for details.\n");

      printf ("Report %s bugs to %s\n", program_name, PACKAGE_BUGREPORT);
      printf ("%s home page: <%s>\n", PACKAGE_NAME, PACKAGE_URL);
    }

  exit (status);
}

void
print_version (void)
{
  printf ("%s (%s) %s\n", program_name, PACKAGE_NAME, PACKAGE_VERSION);
  puts (LICENSE);
  puts ("Written by Guilherme A. Suckevicz.");
  exit (EXIT_SUCCESS);
}

void
show_date (const char *format)
{
  time_t now;
  struct tm *tm;
  size_t size;
  char *buf;

  /* buffer needs space to a '\n'. */
  size = DEFAULT_SIZE;
  buf = xmalloc (size);

  now = time (NULL);
  if (now == (time_t) -1)
    err_quit ("cannot get time");

  tm = localtime (&now);
  if (tm == NULL)
    err_quit ("cannot get localtime value");

  /* Ensure that there are space enough to hold the format. */
  while (strftime (buf, size, format, tm) == 0)
    {
      free (buf);
      size *= 2;
      buf = xmalloc (size);
    }

  printf ("%s\n", buf);
  free (buf);
}

int
main (int argc, char **argv)
{
  int optc;
  char *format = DEFAULT_FORMAT;

  struct option longopts[] =
    {
      {"utc", no_argument, NULL, 'u'},
      {"help", no_argument, NULL, 'h'},
      {"version", no_argument, NULL, 'v'},
      {NULL, 0, NULL, 0}
    };

  program_name = argv[0];

  while ((optc = getopt_long (argc, argv, "uhv", longopts, NULL)) != -1)
    {
      switch (optc)
	{
	  /* Show UTC date and time rather then the default. */
	case 'u':
	  if (putenv ("TZ=UTC0"))
	    err_quit ("cannot set variable TZ in the environment");
	  break;

	case 'h':
	  usage (EXIT_SUCCESS);
	  break;
	case 'v':
	  print_version ();
	  break;

	default:
	  usage (EXIT_FAILURE);
	  break;
	}
    }

  if (optind < argc)
    {
      if (argv[optind][0] == '+')
	{
	  format = argv[optind];
	  format++;
	}
    }

  show_date (format);
  return 0;
}
