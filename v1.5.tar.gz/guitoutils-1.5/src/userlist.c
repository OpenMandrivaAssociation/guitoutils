#include <config.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdbool.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <grp.h>
#include <pwd.h>
#include <getopt.h>

#include "system.h"

const char *program_name;

void print_passwd (struct passwd *pwd,
		   bool numeric_values, bool prefix, bool initial_group);

void print_group_list (char *user, gid_t gid,
		       bool numeric_values, bool initial_group);

void print_all_users (bool numeric_values, bool prefix, bool initial_group);

void
usage (int status)
{
  if (status != EXIT_SUCCESS)
    fprintf (stderr, "Try '%s -h' for more information.\n", program_name);
  else
    {
      printf ("Usage: %s [OPTION]... [USERNAME]...\n", program_name);
      puts ("Print information about USERNAME.\n");

      puts ("\
 -m, --me              about me -- default option\n\
 -a, --all             show information about all in passwd file\n\
 -n, --numeric         show ID with numeric values\n\
 -p, --no-prefix       do not show prefix names\n\
 -i, --primary-group   output just primary group ID\n\
     --help     show this help and exit\n\
     --version  output version information and exit\n");

      printf ("Report %s bugs to %s\n", program_name, PACKAGE_BUGREPORT);
      printf ("%s home page: <%s>\n", PACKAGE_NAME, PACKAGE_URL);
    }

  exit (status);
}

void
print_version (void)
{
  printf ("%s (%s) %s\n", program_name, PACKAGE_NAME, PACKAGE_VERSION);
  puts (LICENSE);
  puts ("Written by Guilherme A. Suckevicz.");
  exit (EXIT_SUCCESS);
}

int
main (int argc, char **argv)
{
  int optc;

  /* show infomation about everyone in passwd file */
  bool all = false;

  /* show information about who is running */
  bool process_id = false;

  /* show ID's and GID's with numerical values insted
     names */
  bool numeric_values = false;

  /* show preifx -- Username: user */
  bool prefix = true;

  /* output just initial GID without supplementary GID's */
  bool initial_group = false;

  struct option longopts[] = {
    {"me", no_argument, NULL, 'm'},
    {"all", no_argument, NULL, 'a'},
    {"numeric", no_argument, NULL, 'n'},
    {"no-prefix", no_argument, NULL, 'p'},
    {"primary-group", no_argument, NULL, 'i'},
    {"help", no_argument, NULL, 'h'},
    {"version", no_argument, NULL, 'v'},
    {NULL, 0, NULL, 0}
  };


  program_name = argv[0];

  if (argc == 1)
    process_id = true;

  while ((optc = getopt_long (argc, argv, "hvamnpi", longopts, NULL)) != -1)
    {
      switch (optc)
	{
	case 'h':
	  usage (EXIT_SUCCESS);
	  break;
	case 'v':
	  print_version ();
	  break;

	case 'a':
	  all = true;
	  break;

	case 'm':
	  process_id = true;
	  break;

	case 'n':
	  numeric_values = true;
	  break;

	case 'p':
	  prefix = false;
	  break;

	case 'i':
	  initial_group = true;
	  break;

	default:
	  usage (EXIT_FAILURE);
	  break;
	}
    }

  if ((process_id || argc == optind) && !all)
    {
      uid_t uid = getuid ();
      struct passwd *p = getpwuid (uid);

      if (p == NULL)
	error (EXIT_FAILURE, errno, "%u", uid);
      else
	print_passwd (p, numeric_values, prefix, initial_group);
    }
  else if (all)
    print_all_users (numeric_values, prefix, initial_group);
  else
    while (optind < argc)
      {
	struct passwd *p = getpwnam (argv[optind]);
	if (p == NULL)
	  {
	    error (0, errno, "%s: no such user", argv[optind++]);
	    continue;
	  }

	print_passwd (p, numeric_values, prefix, initial_group);

	if (++optind < argc)
	  puts ("");
      }

  exit (EXIT_SUCCESS);
}

void
print_all_users (bool numeric_values, bool prefix, bool initial_group)
{
  struct passwd *pwd;
  bool print_nl = true;

  setpwent ();

  while ((pwd = getpwent ()))
    {
      if (print_nl)
	puts ("");

      print_passwd (pwd, numeric_values, prefix, initial_group);
      print_nl = true;
    }

  endpwent ();
}

void
print_group_list (char *user, gid_t gid, bool numeric_values,
		  bool initial_group)
{
  int n_groups = 16;
  gid_t *groups;

  if (initial_group)
    if (numeric_values)
      printf ("%u\n", gid);
    else
      {
	struct group *g = getgrgid (gid);
	if (g == NULL)
	  return;

	printf ("%s\n", g->gr_name);
      }
  else
    {
      groups = (gid_t *) malloc (n_groups * sizeof (gid));
      if (groups == NULL)
	return;

      if (getgrouplist (user, gid, groups, &n_groups) < 0)
	{
	  groups = realloc (groups, n_groups * sizeof (gid));
	  getgrouplist (user, gid, groups, &n_groups);
	}

      while (n_groups-- > 0)
	{
	  if (numeric_values)
	    printf ("%u%s", *groups++, ((n_groups > 0) ? " " : "\n"));
	  else
	    {
	      struct group *grp;

	      grp = getgrgid (*groups++);
	      if (grp == NULL)
		continue;

	      printf ("%s%s", grp->gr_name, ((n_groups > 0) ? " " : "\n"));
	    }
	}
    }
}

void
print_passwd (struct passwd *pwd,
	      bool numeric_values, bool prefix, bool initial_group)
{
  /* print name and gecos */
  printf ("%s%s\n", ((prefix == true) ? "Username: " : ""), pwd->pw_name);
  printf ("%s%s\n", ((prefix == true) ? "Real name: " : ""), pwd->pw_gecos);

  /* print user's id */
  if (prefix)
    printf ("User ID: ");
  if (numeric_values == false)
    printf ("%s\n", pwd->pw_name);
  else
    printf ("%u\n", pwd->pw_uid);

  /* print group's id */
  if (prefix)
    printf ("Group(s) ID: ");
  print_group_list (pwd->pw_name, pwd->pw_gid, numeric_values, initial_group);

  /* print shell and home dir */
  printf ("%s%s\n", ((prefix == true) ? "Home: " : ""), pwd->pw_dir);
  printf ("%s%s\n", ((prefix == true) ? "Shell: " : ""), pwd->pw_shell);
}
