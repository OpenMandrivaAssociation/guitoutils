#include <config.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <getopt.h>
#include <pwd.h>
#include <fts.h>

#include <sys/types.h>
#include <sys/stat.h>

#include "system.h"
#include "xmalloc.h"

const char *program_name;

#ifndef PATH_MAX
#define PATH_MAX 4096
#endif

#ifndef LINE_MAX
#define LINE_MAX PATH_MAX
#endif


/* Enum of files types. */
enum file_type
{
  TYPE_F, TYPE_D
};

/* Verbose modes. */
bool just_deleted;
bool just_not_deleted;

/* Really execute remove. */
bool delete;

/* Option to just print the linked list of pathnames. */
bool just_print_paths;

/* The config file with the filenames to not remove. */
#define DEFAULT_CONFIG_FILE "/etc/clean-user-config"
char *config_file;

/* Linked list to manage the pathnames in the config file. */
struct node
{
  char *filename;
  struct node *next;
};

struct linked_list
{
  struct node *first;
};
struct linked_list *config_list;

void
usage (int status)
{
  if (status != EXIT_SUCCESS)
    fprintf (stderr, "Try '%s -h' for more information.\n",
	     program_name);
  else
    {
      printf ("Usage: %s [OPTION]\n\n", program_name);
      puts ("\
  -p       just print the config list\n\
  -f FILE  config list with pathnames to not be removed\n\
  -d       verbose just files that will be removed\n\
  -n       verbose just files that will not be removed\n\
  -v       verbose both\n\
  -e       really execute the remove\n\
  -h       show this help and exit\n\
  -V       display version information and exit\n");

      printf ("Report %s bugs to %s\n", program_name, PACKAGE_BUGREPORT);
      printf ("%s home page: <%s>\n", PACKAGE_NAME, PACKAGE_URL);
    }

  exit (status);
}

void
print_version (void)
{
  printf ("%s (%s) %s\n", program_name, PACKAGE_NAME, PACKAGE_VERSION);
  puts (LICENSE);
  puts ("Written by Guilherme A. Suckevicz.");
  exit (EXIT_SUCCESS);
}

struct node *
make_node (const char *pathname)
{
  struct node *n;

  n = xmalloc (sizeof (struct node));
  n->filename = xstrdup (pathname);
  n->next = NULL;

  return n;
}

void
list_add (struct linked_list *list, const char *pathname)
{
  struct node *n;

  if (list->first == NULL)
    {				/* First element. */
      list->first = make_node (pathname);
    }
  else
    {
      n = list->first;
      while (n->next)
	n = n->next;
      n->next = make_node (pathname);
    }
}

void
clean_list (struct linked_list *list)
{
  struct node *n, *next;

  n = list->first;
  while (n)
    {
      next = n->next;
      free (n->filename);
      free (n);
      n = next;
    }
}

void
print_list (struct linked_list *list)
{
  struct node *n;

  n = list->first;
  while (n)
    {
      printf ("%s\n", n->filename);
      n = n->next;
    }
}

void
load_config_file (void)
{
  char line[LINE_MAX];
  FILE *fp;

  fp = fopen (config_file, "r");
  if (!fp)
    err_quit ("cannot open file '%s' for reading", config_file);

  while (fgets (line, LINE_MAX, fp))
    {
      if (line[strlen (line) - 1] == '\n')
	line[strlen (line) - 1] = '\0';
      if (line[strlen (line) - 1] == '/')
	line[strlen (line) - 1] = '\0';

      list_add (config_list, line);
    }
  fclose (fp);
}

void
enter_user_home (void)
{
  uid_t uid;
  struct passwd *pwd;

  uid = getuid ();

  pwd = getpwuid (uid);
  if (pwd == NULL)
    err_quit ("cannot get user information, id = %d", uid);

  if (chdir (pwd->pw_dir) < 0)
    err_quit ("cannot enter in user home directory '%s'", pwd->pw_dir);
}

bool
search_path_in_list (struct linked_list *list, char *pathname)
{
  struct node *n;

  n = list->first;
  while (n)
    {
      if (STREQ (pathname, n->filename) || STREQ (pathname + 2, n->filename))
	return true;
      n = n->next;
    }
  return false;
}

void
analize_parents (FTSENT * ent)
{
  static char path[PATH_MAX];
  int level;
  char *slash;

  strncpy (path, ent->fts_path, PATH_MAX);
  level = ent->fts_level;
  slash = strrchr (path, '/');
  if (!slash)
    return;
  while (--level)
    {
      *slash = '\0';
      /* If the pathname is not already in the list,
       * add it. */
      if (!search_path_in_list (config_list, path))
	list_add (config_list, path);
      slash--;
      slash = strrchr (path, '/');
      if (!slash)
	return;
    }
}

void
print_file_type (enum file_type filetype)
{
  switch (filetype)
    {
    case TYPE_F:
      printf ("file");
      break;

    case TYPE_D:
      printf ("directory");
      break;
    }
}

bool
process_file (FTS * fts, FTSENT * ent)
{
  bool found;
  enum file_type filetype;

  switch (ent->fts_info)
    {
      /* A directory being visited in preorder. */
    case FTS_D:
      if (!search_path_in_list (config_list, ent->fts_path))
	return true;
      break;

      /* A directory which cannot be read. */
    case FTS_DNR:
      error (EXIT_FAILURE, ent->fts_errno, "directory cannot be read '%s'",
	     ent->fts_path);
      break;

      /* This is an error return. */
    case FTS_ERR:
      error (EXIT_FAILURE, ent->fts_errno, "%s", ent->fts_path);
      break;

    default:
      break;
    }

  filetype = TYPE_F;

  if (search_path_in_list (config_list, ent->fts_path))
    {
      found = true;
      if (S_ISDIR (ent->fts_statp->st_mode))
	{
	  filetype = TYPE_D;
	  fts_set (fts, ent, FTS_SKIP);
	}
      else
	filetype = TYPE_F;
      if (ent->fts_level > 1)
	analize_parents (ent);
    }
  else
    {
      found = false;
    }

  if (just_deleted && !found)
    {
      printf ("Removing ");
      print_file_type (filetype);
      printf (": %s\n", ent->fts_path);
    }
  if (just_not_deleted && found)
    {
      printf ("Not removing ");
      print_file_type (filetype);
      printf (": %s\n", ent->fts_path);
    }

  if (found)
    return true;
  else if (delete && remove (ent->fts_path) < 0)
    err_quit ("cannot remove file '%s'", ent->fts_path);

  return true;
}

bool
process_files (char **files)
{
  bool ok;
  FTS *fts;
  char *filename;

  ok = true;

  fts = fts_open (files, FTS_PHYSICAL | FTS_NOCHDIR, NULL);
  if (fts == NULL)
    err_quit ("fts_open error");

  while (1)
    {
      FTSENT *ent;

      ent = fts_read (fts);
      if (ent == NULL)
	{
	  if (errno != 0)
	    err_quit ("fts_read error");
	  break;
	}

      /* Just process files with a '.' dot in the first character
       * of the filename. */
      if (ent->fts_level <= 0)
	continue;
      else
	filename = ent->fts_path + 2;

      if (filename[0] != '.')
	{
	  if (S_ISDIR (ent->fts_statp->st_mode))
	    {
	      fts_set (fts, ent, FTS_SKIP);
	    }
	  continue;
	}

      ok &= process_file (fts, ent);
    }

  if (fts_close (fts) < 0)
    err_quit ("fts_close error");

  return ok;
}

int
main (int argc, char **argv)
{
  int optc;
  bool ok;
  char *files[] = { ".", NULL };

  struct option longopts[] =
    {
      {"file", required_argument, NULL, 'f'},
      {"print", no_argument, NULL, 'p'},
      {"delete", no_argument, NULL, 'd'},
      {"not-delete", no_argument, NULL, 'n'},
      {"verbose", no_argument, NULL, 'v'},
      {"execute", no_argument, NULL, 'e'},
      {LONGOPT_HELP},
      {LONGOPT_VERSION},
      {NULL, 0, NULL, 0}
    };

  program_name = argv[0];
  ok = true;

  just_deleted = false;
  just_not_deleted = false;
  just_print_paths = false;
  delete = false;
  config_file = DEFAULT_CONFIG_FILE;

  /* Init linked list of filenames. */
  config_list = xmalloc (sizeof (struct linked_list));
  config_list->first = NULL;

  while ((optc = getopt_long (argc, argv, "f:pdnve", longopts, NULL))
	 != -1)
    {
      switch (optc)
	{
	case 'f':
	  config_file = optarg;
	  break;

	case 'p':
	  just_print_paths = true;
	  break;

	case 'v':
	  just_deleted = true;
	  just_not_deleted = true;
	  break;
	case 'd':
	  just_deleted = true;
	  break;
	case 'n':
	  just_not_deleted = true;
	  break;

	case 'e':
	  delete = true;
	  break;

	case GETOPT_HELP_CHAR:
	  usage (EXIT_SUCCESS);
	  break;
	case GETOPT_VERSION_CHAR:
	  print_version ();
	  break;

	default:
	  usage (EXIT_SUCCESS);
	  break;
	}
    }

  /* Load filenames in a linked list. */
  load_config_file ();

  if (just_print_paths)
    {
      print_list (config_list);
    }
  else
    {
      enter_user_home ();
      ok = process_files (files);
    }

  clean_list (config_list);
  exit (ok ? EXIT_SUCCESS : EXIT_FAILURE);
}
