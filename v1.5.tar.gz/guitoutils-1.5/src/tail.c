#include <config.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <getopt.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>

#include <sys/stat.h>

#include "xmalloc.h"
#include "system.h"

/* To compile:
   gcc lib/xmalloc.o tail.c -o tail -Ilib/ */

#define DEFAULT_VALUE 10

#define IS_TAILABLE(mode) (S_ISREG (mode) || S_ISFIFO (mode))

const char *program_name;

/* Option for tail lines or bytes, default is lines. */
bool lines = true;

/* Option for tail from end or from start. */
bool from_start = false;

/* Follow option. */
bool follow = false;


struct file_spec
{
  int fd;
  char *filename;
  bool can_follow;
  off_t size;
  time_t mtime;
};

void
usage (int status)
{
  if (status != EXIT_SUCCESS)
    fprintf (stderr, "Try '%s --help' for more information.\n", program_name);
  else
    {
      printf ("Usage: %s [OPTION]... [FILE]...\n\n", program_name);

      puts ("\
  -n, --lines=NUM  print the last NUM lines of FILE\n\
  -c, --bytes=NUM  print the last NUM bytes of FILE\n\
  -f, --follow     do not terminate after copy, read further bytes\n\
                     when they become available\n\
      --help     show this help and exit\n\
      --version  display version information and exit\n");

      printf ("Report %s bugs to %s\n", program_name, PACKAGE_BUGREPORT);
      printf ("%s home page: <%s>\n", PACKAGE_NAME, PACKAGE_URL);
    }

  exit (status);
}

void
print_version (void)
{
  printf ("%s (%s) %s\n", program_name, PACKAGE_NAME, PACKAGE_VERSION);
  puts (LICENSE);
  puts ("Written by Guilherme A. Suckevicz.");
  exit (EXIT_SUCCESS);
}

off_t
xlseek (char *filename, int fd, off_t offset, int whence)
{
  int ret = lseek (fd, offset, whence);
  if (ret == (off_t) -1)
    err_quit ("cannot lseek on file '%s'", filename);
  return ret;
}

int
close_fd (int fd, char *filename)
{
  if (fd != STDIN_FILENO && close (fd) < 0)
    err_quit ("cannot close '%s' (fd=%d)", filename, fd);
  return 0;
}

void
tail_lines (char *filename, int fd, uintmax_t n_units)
{
  size_t nread;
  char buffer[BUFSIZ];
  char *newline, *p, *endbuf;
  uintmax_t count, i;

  struct linebuffer
  {
    bool entire_line;
    size_t size;
    char *buf;
  };
  struct linebuffer *lines, *lb;

  if (n_units == 0)
    return;

  lines = malloc (sizeof (struct linebuffer) * n_units);
  if (!lines)
    err_quit ("Memory error");

  for (count = 0; count < n_units; count++)
    {
      lines[count].entire_line = true;
      lines[count].size = 0;
      lines[count].buf = NULL;
    }

  count = 0;

  for (;;)
    {
      nread = read (fd, buffer, BUFSIZ);
      if (nread == -1)
        err_quit ("read error on %s", filename);
      if (nread == 0)
	break;

      p = buffer;
      endbuf = buffer + nread;
      for (;;)
	{
	  newline = memchr (p, '\n', endbuf - p);
	  if (!newline)
	    {
	      if (p != endbuf)
		{
		  lb = &lines[count];

		  /* First, we have to clean the previous content of the line,
		     so we can use the line count for the new one. */
		  if (lb->entire_line)
		    {
		      lb->size = 0;
		      free(lines[count].buf);
		      lines[count].buf = NULL;
		    }
		  lb->entire_line = false;

		  if (lb->buf != NULL)
		    {
		      /* The line already have a content, realloc it.
			 For example, 2 following reads do not found a new line. */
		      lb->buf = realloc (lb->buf, lb->size + endbuf - p);
		      memcpy (lb->buf + lb->size, p, endbuf - p);
		      lb->size += endbuf - p;
		    }
		  else
		    {
		      /* Copy the buffer content. There is no newline here. */
		      lb->size = endbuf - p;
		      lb->buf = xmalloc (lb->size);
		      memcpy (lb->buf, p, lb->size);
		    }
		}

	      break;
	    }
	  else if (lines[count].entire_line == false)
	    {
	      lb = &lines[count];

	      newline++;
	      lb->entire_line = true;
	      lb->size += newline - p;
	      lb->buf = realloc (lb->buf, lb->size);
	      if (!lb->buf)
		err_quit ("Memory error");

	      memcpy (lb->buf + lb->size - (newline - p), p, newline - p);

	      p = newline;
	      if (++count == n_units)
		count = 0;

	      continue;
	    }

	  newline++;
	  lb = &lines[count];

	  /* Check if the line is used. */
	  if (lb->buf != NULL)
	    {
	      lb->entire_line = true;
	      lb->size = 0;
	      free (lb->buf);
	    }

	  lb->entire_line = true;
	  lb->size = newline - p;
	  lb->buf = malloc (lb->size);
	  if (!lb->buf)
	    err_quit ("Memory error");

	  memcpy (lb->buf, p, lb->size);

	  p = newline;
	  count++;
	  if (count == n_units)
	    count = 0;
	}
    }


  for (i = 0; i < n_units; i++)
    {
      count = count % n_units;

      fwrite (lines[count].buf, 1, lines[count].size, stdout);
      free (lines[count].buf);
      count++;
    }

  free (lines);
}

void
tail_bytes (char *filename, int fd, uintmax_t n_units)
{
  size_t nread;
  char buffer[BUFSIZ], save_buffer[BUFSIZ];
  uintmax_t total_read, count;
  char *p;

  struct bytesbuffer
  {
    size_t size;
    char *buf;
    struct bytesbuffer *next;
  };
  struct bytesbuffer *first, *node, *tmp, *last;

  first = NULL;
  total_read = 0;

  if (n_units == 0)
    return;

  for (;;)
    {
      nread = read (fd, buffer, BUFSIZ);
      if (nread == -1)
	err_quit ("read error on %s", filename);
      if (nread == 0)
	break;

      node = xmalloc (sizeof (struct bytesbuffer));
      if (first == NULL)
	first = node;
      else
	{
	  tmp = first;
	  while (tmp->next != NULL)
	    tmp = tmp->next;
	  tmp->next = node;
	}
      node->next = NULL;

      if (nread >= n_units)
	p = buffer + nread - n_units;
      else
	p = buffer;

      node->size = buffer + nread - p;
      /* printf ("nread = %d, node->size = %d", nread, node->size); */

      node->buf = xmalloc (node->size);
      memcpy (node->buf, p, node->size);

      total_read += node->size;
      /* puts (""); */
      if (total_read <= n_units)
	continue;

      node = first;
      last = first;
      while (node && total_read > n_units)
	{
	  /* printf ("total_read = %lld", total_read); */
	  count = total_read - n_units;

	  if (count >= node->size)
	    {
	      /* printf (", delete all node (%d to 0)", node->size); */
	      total_read -= node->size;
	      tmp = node;
	      if (node == first)
		first = node->next;
	      else
		last->next = node->next;
	      free (tmp->buf);
	      free (tmp);
	    }
	  else
	    {
	      /* printf (", rezising node (%d to %d)", node->size, node->size - count); */
	      p = node->buf + count;
	      memcpy (save_buffer, p, node->size - count);

	      free (node->buf);
	      node->size -= count;
	      node->buf = xmalloc (node->size);
	      memcpy (node->buf, save_buffer, node->size);

	      total_read -= count;
	    }

	  /* printf (", delete = %lld, new total_read = %lld\n", count, total_read); */
	  last = node;
	  node = node->next;
	}
    }

  node = first;
  while (node)
    {
      fwrite (node->buf, 1, node->size, stdout);
      tmp = node;
      node = node->next;
      free (tmp->buf);
      free (tmp);
    }
}

void
tail_lines_from_start (char *filename, int fd, uintmax_t n_units)
{
  size_t nread;
  char buffer[BUFSIZ];
  char *newline, *p, *endbuf;

  for (;;)
    {
      nread = read (fd, buffer, BUFSIZ);
      if (nread == -1)
	err_quit ("read error on %s", filename);
      if (nread == 0)
	break;

      if (n_units == 0)
	fwrite (buffer, 1, nread, stdout);
      else
	{
	  p = buffer;
	  endbuf = p + nread;
	  for (;;)
	    {
	      newline = memchr (p, '\n', endbuf - p);
	      if (!newline)
		break;

	      newline++;

	      if (n_units > 0)
		n_units--;
	      else if (n_units == 0)
		fwrite (p, 1, newline - p, stdout);
	      p = newline;
	    }

	  if (p != endbuf && n_units == 0)
	    fwrite (p, 1, endbuf - p, stdout);
	}
    }
}

void
tail_bytes_from_start (char *filename, int fd, uintmax_t n_units)
{
  size_t nread;
  char buffer[BUFSIZ];
  char *p;

  for (;;)
    {
      nread = read (fd, buffer, BUFSIZ);
      if (nread == -1)
	err_quit ("read error on %s", filename);
      if (nread == 0)
	break;

      if (n_units == 0)
	{
	  fwrite (buffer, 1, nread, stdout);
	  continue;
	}

      if (nread < n_units)
	n_units -= nread;
      else
	{
	  char *endbuf;

	  endbuf = buffer + nread;

	  p = buffer + n_units;
	  fwrite (p, 1, endbuf - p, stdout);

	  n_units = 0;
	}
    }
}

void
tail (char *filename, int fd, uintmax_t n_units, bool lines, bool from_start)
{
  if (!from_start)
    if (lines)
      tail_lines (filename, fd, n_units);
    else
      tail_bytes (filename, fd, n_units);

  else if (lines)
    tail_lines_from_start (filename, fd, n_units);
  else
    tail_bytes_from_start (filename, fd, n_units);
}

void
tail_file (struct file_spec *f, uintmax_t n_units)
{
  int fd;
  bool standard_input = (*(f->filename) == '-');
  struct stat stat_buf;

  if (standard_input)
    {
      fd = STDIN_FILENO;
      tail (f->filename, fd, n_units, lines, from_start);
    }
  else
    {
      fd = open (f->filename, O_RDONLY);
      if (fd < 0)
	err_quit ("cannot open file '%s'", f->filename);
      tail (f->filename, fd, n_units, lines, from_start);
    }

  if (! follow)
    {
      if (close_fd (fd, f->filename) < 0)
	err_quit ("cannot close file '%s'", f->filename);
      return;
    }

  /* If follow option is enable, dont close the file descriptor
     to allow further IO on it. */

  if (fstat (fd, &stat_buf) < 0)
    err_quit ("cannot fstat file '%s' (fd=%d)", f->filename, fd);
  else if (! IS_TAILABLE (stat_buf.st_mode))
    {
      f->fd = -1;
      f->can_follow = false;
      if (close_fd (fd, f->filename) < 0)
	err_quit ("cannot close file '%s'", f->filename);
    }
  else
    {
      f->fd = fd;
      f->can_follow = true;
      f->size = stat_buf.st_size;
      f->mtime = stat_buf.st_mtime;
    }
}

void
print_remainder (char *filename, int fd)
{
  size_t nread;
  char buffer[BUFSIZ];

  for (;;)
    {
      nread = read (fd, buffer, BUFSIZ);
      if (nread == -1)
	err_quit ("read error on file '%s'", filename);

      if (nread == 0)
	break;

      fwrite (buffer, 1, nread, stdout);
    }
}

void
tail_forever (struct file_spec *files, int nfiles)
{
  int i;
  struct stat st;
  struct file_spec *f;

  for (i = 0; ; i++)
    {
      if (i == nfiles)
	i = 0;

      if (files[i].fd < 0)
	continue;
      f = &files[i];

      if (fstat (f->fd, &st) < 0)
	{
	  err_quit ("cannot stat file '%s'", f->filename);
	  f->fd = -1;
	}
      else
	{
	  if (f->size != st.st_size || f->mtime != st.st_mtime)
	    {
	      if (f->size >= st.st_size)
		{
		  error (0, 0, "%s: file truncated", f->filename);
		  xlseek (f->filename, f->fd, 0, SEEK_SET);
		}
	      else
		{
		  print_remainder (f->filename, f->fd);
		}

	      f->size = st.st_size;
	      f->mtime = st.st_mtime;
	    }
	}

      sleep (1);
    }
}

uintmax_t
strtoui (char *arg, bool lines)
{
  uintmax_t n;
  char *parg;

  if (*arg == '\0')
    {
      error (EXIT_FAILURE, 0, "%s: invalid number of %s", arg,
	     ((lines) ? "lines" : "bytes"));
    }

  parg = arg;
  while (*parg)
    {
      if (!isdigit (*parg))
	{
	  error (EXIT_FAILURE, 0, "%s: invalid number of %s", arg,
		 ((lines) ? "lines" : "bytes"));
	}
      parg++;
    }

  errno = 0;
  n = strtoull (optarg, NULL, 10);
  if (errno != 0)
    err_quit ("%s: invalid number of %s", arg, (lines) ? "lines" : "bytes");

  return n;
}

int
main (int argc, char **argv)
{
  int opt;
  int i, nfiles;

  /* Units to output. */
  uintmax_t n_units = DEFAULT_VALUE;


  struct file_spec *files;
  char *stdin_name = "-";
  char **file;

  struct option longopts[] =
    {
      {"bytes", required_argument, NULL, 'c'},
      {"lines", required_argument, NULL, 'n'},
      {"follow", no_argument, NULL, 'f'},
      {"help", no_argument, NULL, 'h'},
      {"version", no_argument, NULL, 'v'},
      {NULL, 0, NULL, 0}
    };

  program_name = argv[0];

  while ((opt = getopt_long (argc, argv, "c:n:fhv", longopts, NULL)) != -1)
    {
      switch (opt)
	{
	case 'c':
	  lines = false;

	  from_start = *(optarg) == '+';
	  if (from_start || *optarg == '-')
	    optarg++;
	  n_units = strtoui (optarg, lines);
	  break;

	case 'n':
	  lines = true;

	  from_start = *(optarg) == '+';
	  if (from_start || *optarg == '-')
	    optarg++;
	  n_units = strtoui (optarg, lines);
	  break;

	case 'f':
	  follow = true;
	  break;

	case 'h':
	  usage (EXIT_SUCCESS);
	  break;
	case 'v':
	  print_version ();
	  break;

	default:
	  usage (EXIT_FAILURE);
	  break;
	}
    }

  if (argc - optind == 0)
    {
      nfiles = 1;
      file = &stdin_name;
    }
  else
    {
      nfiles = argc - optind;
      file = argv + optind;
    }

  files = xmalloc (sizeof (struct file_spec) * nfiles);
  for (i = 0; i < nfiles; i++)
    files[i].filename = file[i];

  if (from_start && n_units > 0)
    n_units--;

  if (argc == optind)
    tail_file (&files[0], n_units);
  else
    {
      i = 0;
      while (i < nfiles)
	{
	  tail_file (&files[i], n_units);
	  i++;
	}
    }

  if (follow)
    tail_forever (files, nfiles);

  return 0;
}
