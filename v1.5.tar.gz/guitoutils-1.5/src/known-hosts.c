#include <config.h>

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <getopt.h>
#include <pwd.h>

#include <sys/types.h>
#include <sys/stat.h>

#include "system.h"
#include "xmalloc.h"

#ifndef LINE_MAX
# define LINE_MAX 2048
#endif

/* Default file to search in. */
#define SSH_KNOWN_HOSTS ".ssh/known_hosts"

const char *program_name;

/* File to search names. */
static char *known_hosts_file;

/* Enable verbose. */
static bool verbose;

/* Option to just print the known hosts file. */
static bool print;

void
usage (int status)
{
  if (status != EXIT_SUCCESS)
    fprintf (stderr, "Try '%s --help' for more information.\n",
	     program_name);
  else
    {
      printf ("Usage: %s [OPTION]... HOSTNAME\n\n", program_name);

      puts ("\
  -f, --file=FILE  file to search hostnames\n\
  -v, --verbose    enable verbose output\n\
      --help     show this help and exit\n\
      --version  display version information and exit\n");

      printf ("Report %s bugs to %s\n", program_name, PACKAGE_BUGREPORT);
      printf ("%s home page: <%s>\n", PACKAGE_NAME, PACKAGE_URL);
    }

  exit (status);
}

void
print_version (void)
{
  printf ("%s (%s) %s\n", program_name, PACKAGE_NAME, PACKAGE_VERSION);
  puts (LICENSE);
  puts ("Written by Guilherme A. Suckevicz.");
  exit (EXIT_SUCCESS);
}

static void
adjust_file_name (void)
{
  uid_t uid;
  struct passwd *pwd;
  char *path;

  uid = getuid ();

  pwd = getpwuid (uid);
  if (pwd == NULL)
    {
      error (EXIT_FAILURE, errno,
	     "no name found for uid %d", uid);
    }

  path = xmalloc (strlen (SSH_KNOWN_HOSTS)
		  + strlen (pwd->pw_dir));
  strcpy (path, pwd->pw_dir);
  strcat (path, "/");
  strcat (path, SSH_KNOWN_HOSTS);

  known_hosts_file = path;
}

static void
make_backup_file (void)
{
  char *backup_file;
  int fd, fd_backup;
  char buffer[BUFSIZ];
  size_t nread;

  backup_file = xmalloc (strlen (known_hosts_file) + 2);
  strcpy (backup_file, known_hosts_file);
  strcat (backup_file, "~");

  fd = open (known_hosts_file, O_RDONLY);
  if (fd < 0)
    {
      error (EXIT_FAILURE, errno, "cannot open file '%s' for reading",
	     known_hosts_file);
    }


  fd_backup = open (backup_file, O_WRONLY | O_CREAT,
		    S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
  if (fd_backup < 0)
    {
      error (EXIT_FAILURE, errno, "cannot create backup file '%s' for writing",
	     backup_file);
    }

  while (1)
    {
      nread = read (fd, buffer, BUFSIZ);
      if (nread == -1)
	{
	  error (EXIT_FAILURE, errno,
		 "read error on '%s'", known_hosts_file);
	}
      if (nread == 0)
	break;

      if (write (fd_backup, buffer, nread) != nread)
	{
	  error (EXIT_FAILURE, errno, "write error on '%s'",
		 backup_file);
	}
    }

  close (fd);
  close (fd_backup);
}

static size_t
getline_from_buffer (char *buf, size_t nread, char *line)
{
  char *newline;
  
  while (1)
    {
      newline = memchr (buf, '\n', nread);
      if (newline == NULL)
	{
	  /* Not found a newline in the buffer. */
	  return -1;
	}

      if (newline - buf > LINE_MAX)
	{
	  error (EXIT_FAILURE, errno,
		 "exceed line limit, this seems like a syntax error");
	}
      else
	{
	  /* Line size plus 1 because of the '\n'. */
	  memcpy (line, buf, newline - buf + 1);
	  return newline - buf + 1;
	}
    }
}

static void
write_line (int tmp_fd, char *line, size_t nline)
{
  if (write (tmp_fd, line, nline) != nline)
    {
      error (EXIT_FAILURE, errno,
	     "write error on temporary file");
    }
}

static bool
found_host_in_line (char *line, char *hostname)
{
  char *p;
  static char field[LINE_MAX];

  p = memchr (line, ' ', LINE_MAX);
  if (p == NULL)
    return false;

  memcpy (field, line, p - line);
  field[p - line] = '\0';

  if (verbose)
    printf ("%s - ", field);

  return (strstr (field, hostname) ? true : false );
}

static bool
process_host_name (char *hostname, int tmp_fd)
{
  int fd;
  char buffer[BUFSIZ], *buf;
  char line[LINE_MAX];
  size_t nread, nline;
  ssize_t n_to_read;
  bool overwrite;
  
  fd = open (known_hosts_file, O_RDONLY);
  if (fd < 0)
    {
      error (EXIT_FAILURE, errno, "cannot open file '%s' for reading",
	     known_hosts_file);
    }

  n_to_read = BUFSIZ;
  overwrite = false;

  nread = read (fd, buffer, n_to_read);
  if (nread == -1)
    {
      error (EXIT_FAILURE, errno, "read error on '%s'\n",
	     known_hosts_file);
    }

  buf = buffer;
  while (1)
    {
      nline = getline_from_buffer (buf, nread, line);
      if (nline == -1)
	{
	  size_t n_read;

	  n_read = read (fd, buffer + nread, n_to_read - nread);
	  if (n_read == -1)
	    {
	      error (EXIT_FAILURE, errno, "read error on '%s'",
		     known_hosts_file);
	    }
	  if (n_read == 0)
	    break;

	  buf = buffer;
	  nread += n_read;
	  continue;
	}

      nread -= nline;
      if (found_host_in_line (line, hostname))
	{
	  if (verbose)
	    puts ("found");
	  overwrite = true;
	}
      else
	{
	  write_line (tmp_fd, line, nline);

	  if (verbose)
	    puts ("not found");
	}

      memmove (buf, buf + nline, nread);
    }

  if (close (fd) < 0)
    {
      error (EXIT_FAILURE, errno, "cannot close file '%s'",
	     known_hosts_file);
    }

  return overwrite;
}

static void
copy_file (int tmp_fd)
{
  int fd;
  char buffer[BUFSIZ];
  size_t nread;

  /* Go to the begining of tmp file. */
  if (lseek (tmp_fd, 0, SEEK_SET) == (off_t) -1)
    {
      error (EXIT_FAILURE, errno,
	     "cannot seek on temporary file");
    }

  fd = open (known_hosts_file, O_WRONLY | O_TRUNC);
  if (fd == -1)
    {
      error (EXIT_FAILURE, errno, "cannot open file '%s' for writing",
	     known_hosts_file);
    }

  while (1)
    {
      nread = read (tmp_fd, buffer, BUFSIZ);
      if (nread == -1)
	{
	  error (EXIT_FAILURE, errno,
		 "read error on temporary file");
	}
      if (nread == 0)
	break;

      if (write (fd, buffer, nread) != nread)
	{
	  error (EXIT_FAILURE, errno, "write error on file '%s'",
		 known_hosts_file);
	}
    }

  if (close (fd) < 0)
    {
      error (EXIT_FAILURE, errno, "cannot close file '%s'",
	     known_hosts_file);
    }
}

int
main (int argc, char **argv)
{
  int optc, tmp_fd;
  bool overwrite;
  char template[] = "known_hostsXXXXXX";

  /* Hostname to search in. */
  char *hostname;

  struct option longopts[] =
    {
      {"file", required_argument, NULL, 'f'},
      {"verbose", no_argument, NULL, 'v'},
      {"print", no_argument, NULL, 'p'},
      {LONGOPT_HELP},
      {LONGOPT_VERSION},
      {NULL, 0, NULL, 0}
    };

  program_name = argv[0];

  known_hosts_file = NULL;
  verbose = false;
  print = false;

  while ((optc = getopt_long (argc, argv, "f:vp", longopts, NULL)) != -1)
    {
      switch (optc)
	{
	case 'f':
	  known_hosts_file = optarg;
	  break;

	case 'v':
	  verbose = true;
	  break;

	case 'p':
	  print = true;
	  break;

	case GETOPT_HELP_CHAR:
	  usage (EXIT_SUCCESS);
	  break;
	case GETOPT_VERSION_CHAR:
	  print_version ();
	  break;

	default:
	  usage (EXIT_FAILURE);
	  break;
	}
    }

  if (optind == argc)
    {
      error (0, 0, "missing arguments.");
      usage (EXIT_FAILURE);
    }

  tmp_fd = mkstemp (template);
  if (tmp_fd < 0)
      err_quit ("cannot create temporary file");

  /* If not specified a file, adjust the default name to
     the home user config file. */
  if (! known_hosts_file)
    {
      adjust_file_name ();
    }

  /* Create a backup of ssh known_hosts file. */
  make_backup_file ();

  hostname = argv[optind];
  overwrite = process_host_name (hostname, tmp_fd);

  if (overwrite)
    copy_file (tmp_fd);

  close (tmp_fd);
  unlink (template);

  exit (EXIT_SUCCESS);
}
