#include <config.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <stdbool.h>
#include <ctype.h>
#include <getopt.h>

#include "xmalloc.h"
#include "system.h"

const char *program_name;

struct request
{
  int count;
  char *req;
};
typedef struct request request;

void
usage (int status)
{
  if (status != EXIT_SUCCESS)
    fprintf (stderr, "Try '%s --help' for more information.\n",
             program_name);
  else
    {
      printf ("Usage: %s [OPTION]...\n", program_name);
      puts ("\
Read entrys in the form COUNT NAME and maintains a table with it,\n\
if the NAME do not exist, add in the table, if NAME already exist\n\
sum your COUNT value for that is there.\n");

      puts ("\
   -V, --verbose   enable verbose and debug information.\n\
       --help     display this information and exit.\n\
       --version  output version information and exit.\n");

      puts ("NOTE: input is from standard input.\n");

      printf ("Report %s bugs to %s\n", program_name, PACKAGE_BUGREPORT);
      printf ("%s home page: <%s>\n", PACKAGE_NAME, PACKAGE_URL);
    }

  exit (status);
}

void
print_version (void)
{
  printf ("%s (%s) %s\n", program_name, PACKAGE_NAME, PACKAGE_VERSION);
  puts (LICENSE);
  printf ("Written by Guilherme A. Suckevicz.\n");
  exit (EXIT_SUCCESS);
}

/* Search the request part in all request storaged,
   return the position found, or -1 on error. */
int
search_request_line (char *line, request *rebuf, int size)
{
  int i;

  /* Skip the request count and the spaces, go until find the request name. */
  while (isdigit (*line) || isspace (*line))
    line++;
  while (isspace (*line))
    line++;

  i = 0;
  while (i < size)
    {
      if (strcmp (line, rebuf[i].req) == 0)
	return i;
      i++;
    }

  return -1;
}

/* Extract the number of counting and the request line.
   The line must be in the format:
   count name
   57 EIN-KITIB
   29536 cgi-bin */
void
create_request (char *line, request *rebuf)
{
  /* Skip spaces and get the number. */
  while (isspace (*line) )
    line++;
  rebuf->count = atoi (line);

  while (isdigit (*line))
    line++;

  /* Go until find a ASCII character. */
  while (isspace (*line))
    line++;
  rebuf->req = strdup (line);
}

/* Add the count number to a existing request. */
void
add_request_count (char *line, request *rebuf)
{
  while (!isdigit (*line))
    line++;
  rebuf->count += atoi (line);
}

/* Default value of different requests. */
#define DEFAULT_SIZE 64

#ifndef LINE_MAX
# define LINE_MAX 1024
#endif

int
main (int argc, char **argv)
{
  int i, optc;
  size_t size, total;
  bool print;
  char line[LINE_MAX];
  request *re_buf;

  struct option longopts[] =
    {
      {"verbose", no_argument, NULL, 'V'},
      {"help", no_argument, NULL, 'h'},
      {"version", no_argument, NULL, 'v'},
      {NULL, 0, NULL, 0}
    };

  program_name = argv[0];

  total = DEFAULT_SIZE;
  print = false;

  while ((optc = getopt_long (argc, argv, "Vhv", longopts, NULL)) != -1)
    {
      switch (optc)
        {
        case 'V':
          print = true;
          break;

        case 'h':
          usage (EXIT_SUCCESS);
          break;
        case 'v':
          print_version ();
          break;

        default:
          usage (EXIT_FAILURE);
          break;
        }
    }

  re_buf = xmalloc (sizeof (request) * total);

  size = 0;
  i = 0;
  while (fgets (line, LINE_MAX, stdin))
    {
      if (line[strlen (line) - 1] == '\n')
	line[strlen (line) - 1] = '\0';

      i = search_request_line (line, re_buf, size);
      if (i == -1)
	{
	  create_request (line, &re_buf[size]);
	  if (print)
	    {
	      printf ("rebuf[%zd].count = %d\n", size, re_buf[size].count);
	      printf ("rebuf[%zd].req = '%s'\n", size, re_buf[size].req);
	    }
	  size++;
	}
      else
	{
	  if (print)
	    printf ("Found a existing request line '%s[%d]'\n", re_buf[i].req, i);
	  add_request_count (line, &re_buf[i]);
	}

      if (size >= total)
        {
          total *= 2;
          if (print)
            printf ("Resizing buffer to: %zd\n", total);
          re_buf = realloc (re_buf, sizeof (request) * total);
        }
    }

  if (print)
    puts ("");

  i = 0;
  while (i < size)
    {
      printf ("%d\t%s\n", re_buf[i].count, re_buf[i].req);
      i++;
    }

  free (re_buf);
  return 0;
}
