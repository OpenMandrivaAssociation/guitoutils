#include <config.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fts.h>
#include <regex.h>

#include "system.h"

#define ERROR_MSG_MAX 256
#define NUM_MATCH_MAX 1


const char *program_name;

/* Compile pattern to use. */
regex_t pattern;

/* Options for matching. */
bool ignore_case = false;
bool extended = false;

/* Just list the directories. */
bool just_list = false;

/* Recursive crossing directories. */
bool recurse = true;

/* Colors options. */
bool colors = true;
static const char *matched_color = "\e[01;31m";
static const char *normal_color = "\e[0m";

void
usage (int status)
{
  if (status != EXIT_SUCCESS)
    fprintf (stderr, "Try '%s --help' for more information.\n",
	     program_name);
  else
    {
      printf ("Usage: %s [OPTION]... [PATTERN [NAME]]...\n", program_name);
      puts ("List directories or search files inside them. :)\n");

      puts ("\
  -i, --ignore-case    ignore case sensitive\n\
  -E, --extended       enable extended regular expressions\n\
  -l, --just-list      just list directorires\n\
  -n, --no-recursive   disable recursion\n\
  -c, --no-colors      disable colors\n\
  -e, --ignore-errors  do not show errors\n\
      --help     show this help and exit\n\
      --version  display version information and exit\n");

      printf ("Report %s bugs to %s\n", program_name, PACKAGE_BUGREPORT);
      printf ("%s home page: <%s>\n", PACKAGE_NAME, PACKAGE_URL);
    }

  exit (status);
}

void
print_version (void)
{
  printf ("%s (%s) %s\n", program_name, PACKAGE_NAME, PACKAGE_VERSION);
  puts (LICENSE);
  puts ("Written by Guilherme A. Suckevicz.");
  exit (EXIT_SUCCESS);
}

void
compile_pattern (const char *pat)
{
  int flags = 0;
  int ret;
  char err_msg[ERROR_MSG_MAX];

  if (ignore_case)
    flags |= REG_ICASE;
  if (extended)
    flags |= REG_EXTENDED;

  ret = regcomp (&pattern, pat, flags);
  if (ret != 0)
    {
      regerror (ret, &pattern, err_msg, sizeof err_msg);
      err_quit ("pattern '%s': %s", pat, err_msg);
    }
}

void
print_colorful (char *filename, regmatch_t *pmatch)
{
  size_t cont;
  regoff_t so, eo;
  char *s;

  so = pmatch->rm_so;
  eo = pmatch->rm_eo;

  cont = 0;
  s = filename;

  while (cont++ < so)
    putchar (*s++);
  printf (matched_color);
  while (cont++ <= eo)
    putchar (*s++);
  printf (normal_color);
  while (*s)
    putchar (*s++);

  putchar ('\n');
}

bool
process_file (FTS *fts, FTSENT *ent)
{
  int ret;
  char err_msg[ERROR_MSG_MAX];
  regmatch_t pmatch[NUM_MATCH_MAX];

  switch (ent->fts_info)
    {
      /* A directory being visited in postorder. */
    case FTS_DP:
      return true;
      break;

      /* A file which no stat information was available.
	 This help to check if the file exist. */
    case FTS_NS:
      error (0, ent->fts_errno, "cannot stat file '%s'",
	     ent->fts_path);
      return false;
      break;

      /* This is an error return. */
    case FTS_ERR:
      error (EXIT_FAILURE, ent->fts_errno, "%s", ent->fts_path);
      break;

      /* A directory which cannot be read. */
    case FTS_DNR:
      error (0, ent->fts_errno, "cannot read directory '%s'",
	     ent->fts_path);
      return false;
      break;

    default:
      break;
    }

  if (! recurse && ent->fts_level >= 1)
    fts_set (fts, ent, FTS_SKIP);

  if (just_list)
    {
      puts (ent->fts_path);
      return true;
    }

  ret = regexec (&pattern, ent->fts_path, NUM_MATCH_MAX, pmatch, 0);
  if (ret != 0)
    {
      if (ret != REG_NOMATCH)
	{
	  regerror (ret, &pattern, err_msg, sizeof err_msg);
	  err_quit ("regexec error on '%s': %s", ent->fts_path, err_msg);
	}
    }
  else
    {
      if (colors)
	print_colorful (ent->fts_path, pmatch);
      else
	puts (ent->fts_path);
    }


  return true;
}

bool
process_directory (char **files)
{
  FTS *fts;
  bool ok = true;

  fts = fts_open (files, FTS_PHYSICAL, NULL);
  if (fts == NULL)
    err_quit ("fts_open error");

  while (1)
    {
      FTSENT *ent;

      ent = fts_read (fts);
      if (ent == NULL)
	{
	  if (errno != 0)
	    err_quit ("fts_read error");
	  break;
	}

      ok &= process_file (fts, ent);
    }

  return ok;
}

int
main (int argc, char **argv)
{
  int optc;
  bool ok = true;

  /* Default pathname. */
  char *default_path[] = {".", NULL};

  struct option longopts[] =
    {
      {"ignore-case", no_argument, NULL, 'i'},
      {"extended", no_argument, NULL, 'E'},
      {"just-list", no_argument, NULL, 'l'},
      {"no-recursive", no_argument, NULL, 'n'},
      {"no-colors", no_argument, NULL, 'c'},
      {"ignore-errors", no_argument, NULL, 'e'},
      {"help", no_argument, NULL, 'h'},
      {"version", no_argument, NULL, 'v'},
      {NULL, 0, NULL, 0}
    };

  program_name = argv[0];

  while ((optc = getopt_long (argc, argv, "iElncehv", longopts, NULL)) != -1)
    {
      switch (optc)
	{
	case 'i':
	  ignore_case = true;
	  break;

	case 'E':
	  extended = true;
	  break;

	case 'l':
	  just_list = true;
	  break;

	case 'n':
	  recurse = false;
	  break;

	case 'c':
	  colors = false;
	  break;

	case 'e':
	  if (freopen ("/dev/null", "w", stderr) == NULL)
	    err_quit ("cannot open file '/dev/null'");
	  break;

	case 'h':
	  usage (EXIT_SUCCESS);
	  break;
	case 'v':
	  print_version ();
	  break;

	default:
	  usage (EXIT_FAILURE);
	  break;
	}
    }

  if (! isatty (STDOUT_FILENO))
    colors = false;

  if (just_list)
    {
      if (optind == argc)
	ok &= process_directory (default_path);
      else
	ok &= process_directory (argv + optind);
    }
  else
    {
      if (optind == argc)
	{
	  just_list = true;
	  ok &= process_directory (default_path);
	}
      else if (optind + 1 == argc)
	{
	  err_ret ("missing operand");
	  usage (EXIT_FAILURE);
	}
      else
	{
	  compile_pattern (argv[optind++]);
	  ok &= process_directory (argv + optind);
	}
    }

  exit (ok ? EXIT_SUCCESS : EXIT_FAILURE);
}
