#include <stdbool.h>
#include <stdint.h>
#include <errno.h>
#include <error.h>
#include <limits.h>

/* License used for all programs. */
#define LICENSE "\
License GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>.\n\
This is free software: you are free to change and redistribute it.\n\
There is NO WARRANTY, to the extent permitted by law.\n"

/* Compare define. */
#define STREQ(s, t) (strcmp (s, t) == 0)


/* Common error routine. */
#define err_quit(s...) \
  error(EXIT_FAILURE, errno, s)

#define err_ret(s...) \
    error(0, errno, s)

/* Enum values to not conflict with the options used by the
   programs.

   See this:
   printf ("%d:%c\n", CHAR_MIN, CHAR_MIN);
   printf ("%d:%c\n", CHAR_MAX, CHAR_MAX);
   printf ("%d:%c\n", (char)GETOPT_HELP_CHAR, GETOPT_HELP_CHAR);
   printf ("%d:%c\n", (char)GETOPT_VERSION_CHAR, GETOPT_VERSION_CHAR); */

enum
  {
    GETOPT_HELP_CHAR = (CHAR_MIN - 2),
    GETOPT_VERSION_CHAR = (CHAR_MIN - 3)
  };

/* Default values to help and version long options. */
#define LONGOPT_HELP \
  "help", no_argument, NULL, GETOPT_HELP_CHAR
#define LONGOPT_VERSION \
  "version", no_argument, NULL, GETOPT_VERSION_CHAR
