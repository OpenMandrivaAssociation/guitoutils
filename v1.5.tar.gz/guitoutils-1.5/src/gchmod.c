#include <config.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <unistd.h>
#include <fts.h>
#include <limits.h>

#include <sys/types.h>
#include <sys/stat.h>

#include "system.h"

const char *program_name;

/* Size of the permissions bits in octal format. */
#define PERM_OCTAL_MAX 4

/* Size of the permissions bits in simbolic format. */
#define PERM_SIMBOLIC_MAX 10

enum verbose_mode
{
  always, when_modified, never
};

struct change_mode
{
  mode_t file_mode;
  mode_t dir_mode;
};


static bool directories;
static bool files;

static bool recursive;

void
usage (int status)
{
  if (status != EXIT_SUCCESS)
    fprintf (stderr, "Try '%s --help' for more information.\n",
	     program_name);
  else
    {
      printf ("Usage: %s [OPTION]... FILE...\n", program_name);
      puts ("Set permissions of file and directories.\n");

      puts ("\
  -f, --file=PERM       apply PERM just to files\n\
  -d, --directory=PERM  apply PERM just to directories\n\
  -v, --verbose         verbose always\n\
  -c, --changes         verbose only when a change happens\n\
  -r, --recursive       apply to all files in the directory\n\
      --help     show this help and exit\n\
      --version  display version information and exit\n\n\
  Note: PERM is a octal value.\n");

      printf ("Report %s bugs to %s\n", program_name, PACKAGE_BUGREPORT);
      printf ("%s home page: <%s>\n", PACKAGE_NAME, PACKAGE_URL);
    }

  exit (status);
}

void
print_version (void)
{
  printf ("%s (%s) %s\n", program_name, PACKAGE_NAME, PACKAGE_VERSION);
  puts (LICENSE);
  puts ("Written by Guilherme A. Suckevicz.");
  exit (EXIT_SUCCESS);
}

mode_t
str_to_mode (char *str)
{
  mode_t mode;
  char *pstr;

  mode = 0;
  pstr = str;

  if (strlen (str) > PERM_OCTAL_MAX)
    err_quit ("invalid mode '%s'", str);

  do
    {
      mode = 8 * mode + *str - '0';
      str++;
    } while ('0' <= *str && *str < '8');

  if (*str)
    err_quit ("invalid mode '%s'", pstr);

  return mode;
}

static char *
mode_to_str (mode_t mode)
{
  static char perm[PERM_SIMBOLIC_MAX];
  size_t offset;

  offset = 0;
  while (offset < PERM_SIMBOLIC_MAX)
    perm[offset++] = '-';

  offset = 0;

  /* User permissions. */
  if (mode & S_IRUSR)
    perm[offset] = 'r';
  offset++;

  if (mode & S_IWUSR)
    perm[offset] = 'w';
  offset++;

  if (mode & S_IXUSR)
    {
      if (mode & S_ISUID)
	perm[offset] = 's';
      else
	perm[offset] = 'x';
    }
  else if (mode & S_ISUID)
    perm[offset] = 'S';
  offset++;


  /* Group permissions. */
  if (mode & S_IRGRP)
    perm[offset] = 'r';
  offset++;

  if (mode & S_IWGRP)
    perm[offset] = 'w';
  offset++;

  if (mode & S_IXGRP)
    {
      if (mode & S_ISGID)
	perm[offset] = 's';
      else
	perm[offset] = 'x';
    }
  else if (mode & S_ISGID)
    perm[offset] = 'S';
  offset++;


  /* Other permissions. */
  if (mode & S_IROTH)
    perm[offset] = 'r';
  offset++;

  if (mode & S_IWOTH)
    perm[offset] = 'w';
  offset++;

  if (mode & S_IXOTH)
    {
      if (mode & S_ISVTX)
	perm[offset] = 't';
      else
	perm[offset] = 'x';
    }
  else if (mode & S_ISVTX)
    perm[offset] = 'T';
  offset++;

  perm[offset] = '\0';
  return perm;
}

void
describe_changes (char *filename, mode_t old_mode, mode_t new_mode,
		  enum verbose_mode verbose)
{
  old_mode = old_mode & ~S_IFMT;
  
  if (verbose == always)
    printf ("mode of '%s' changed from %o (%s) to %o (%s)\n", filename, old_mode,
	    mode_to_str (old_mode), new_mode, mode_to_str (new_mode));
  else if (verbose == when_modified)
    {
      if (old_mode != new_mode)
	printf ("mode of '%s' changed from %o (%s) to %o (%s)\n", filename, old_mode,
		mode_to_str (old_mode), new_mode, mode_to_str (new_mode));
    }
}

bool
process_file (FTS *fts, FTSENT *ent, struct change_mode modes,
	      enum verbose_mode verbose)
{
  int ret;
  mode_t old_mode, new_mode;

  switch (ent->fts_info)
    {
      /* A directory being visited in postorder. */
    case FTS_DP:
      return true;
      break;

      /* A file for which no stat information was available. */
    case FTS_NS:
      error (EXIT_FAILURE, ent->fts_errno, "cannot stat file '%s'", ent->fts_path);
      break;

      /* This is a error return. */
    case FTS_ERR:
      error (EXIT_FAILURE, ent->fts_errno, "%s", ent->fts_path);
      break;

      /* A directory which cannot be read. */
    case FTS_DNR:
      error (EXIT_FAILURE, ent->fts_errno, "cannot read directory '%s'",
	     ent->fts_path);
      break;

    default:
      break;
    }

  /* printf ("%s: %o -> %o\n", ent->fts_path, ent->fts_statp->st_mode & ~S_IFMT,
     modes.file_mode); */

  new_mode = 0;
  old_mode = ent->fts_statp->st_mode;

  if (files && S_ISREG (ent->fts_statp->st_mode))
    {
      ret = chmod (ent->fts_accpath, modes.file_mode);
      if (ret == -1)
	err_quit ("cannot set permissions on '%s'", ent->fts_path);
      new_mode = modes.file_mode;
    }
  else if (directories && S_ISDIR (ent->fts_statp->st_mode))
    {
      ret = chmod (ent->fts_accpath, modes.dir_mode);
      if (ret == -1)
	err_quit ("cannot set permission on '%s'", ent->fts_path);
      new_mode = modes.dir_mode;
    }

  describe_changes (ent->fts_path, old_mode, new_mode, verbose);

  if (! recursive)
    {
      if (fts_set (fts, ent, FTS_SKIP) < 0)
	err_quit ("fts_set error");
    }

  return true;
}

bool
process_files (char **files, struct change_mode modes,
	       enum verbose_mode verbose)
{
  bool ok = true;
  FTS *fts;

  fts = fts_open (files, FTS_PHYSICAL, NULL);
  if (! fts)
    err_quit ("fts_open error");

  while (1)
    {
      FTSENT *ent;

      ent = fts_read (fts);
      if (ent == NULL)
	{
	  if (errno != 0)
	    err_quit ("fts_read error");
	  break;
	}

      ok &= process_file (fts, ent, modes, verbose);
    }

  return ok;
}

int
main (int argc, char **argv)
{
  int optc;
  bool ok = 0;

  enum verbose_mode verbose;
  struct change_mode modes;

  struct option longopts[] =
    {
      {"file", required_argument, NULL, 'f'},
      {"directory", required_argument, NULL, 'd'},
      {"verbose", no_argument, NULL, 'v'},
      {"changes", no_argument, NULL, 'c'},
      {"recursive", no_argument, NULL, 'r'},
      {"help", no_argument, NULL, 'h'},
      {"version", no_argument, NULL, 'V'},
      {NULL, 0, NULL, 0}
    };

  /* Types of files that can be found. */
  directories = false;
  files = false;

  modes.file_mode = 0;
  modes.dir_mode = 0;

  verbose = never;
  recursive = false;

  program_name = argv[0];

  while ((optc = getopt_long (argc, argv, "f:d:vcrhV", longopts, NULL)) != -1)
    {
      switch (optc)
	{
	case 'f':
	  files = true;
	  modes.file_mode = str_to_mode (optarg);
	  break;

	case 'd':
	  directories = true;
	  modes.dir_mode = str_to_mode (optarg);
	  break;

	case 'v':
	  verbose = always;
	  break;

	case 'c':
	  verbose = when_modified;
	  break;

	case 'r':
	  recursive = true;
	  break;

	case 'h':
	  usage (EXIT_SUCCESS);
	  break;
	case 'V':
	  print_version ();
	  break;

	default:
	  usage (EXIT_FAILURE);
	  break;
	}
    }

  if (optind == argc)
    {
      err_ret ("missing operand");
      usage (EXIT_FAILURE);
    }

  ok = process_files (argv + optind, modes, verbose);

  exit (ok ? EXIT_SUCCESS : EXIT_FAILURE);
}
